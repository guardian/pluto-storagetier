from .vidispine_api import HTTPError

def VSException(Exception):
    pass